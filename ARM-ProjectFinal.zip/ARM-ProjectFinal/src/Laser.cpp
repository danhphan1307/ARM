#include "Laser.h"

#define	UPPER_LIMIT_LASER	255
#define	LOWER_LIMIT_LASER	0

Laser::Laser(DigitalIoPin* L)
{
	LASER =L;
	LASER->write(false);
}

void Laser::Power(int power){

	if(power <= UPPER_LIMIT_LASER && power >= LOWER_LIMIT_LASER){
		bool x = (power>120)?true:false;

		LASER->write(x);


	}
}
