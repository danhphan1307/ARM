#include <stdint.h>
#include "chip.h"
#include "DigitalIoPin.h"
#include "FreeRTOS.h"
#include "../freertos/inc/semphr.h"

#ifndef Laser_h
#define Laser_h

class Laser
{
public:
	Laser(DigitalIoPin* L);
	void Power(int power);
private:
	DigitalIoPin* LASER;
};
#endif
